#!/bin/bash
java -Xint -jar InfoTrader.jar
